﻿namespace _18131611
{
    partial class Manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manager));
            this.PasswordInfo_dataGridView = new System.Windows.Forms.DataGridView();
            this.Edit_button = new System.Windows.Forms.Button();
            this.Logout_button = new System.Windows.Forms.Button();
            this.Search_textBox = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.AddPasswordInfo_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddWebsite_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DesktopApp_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Game_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SortPasswordInformaation_button = new System.Windows.Forms.Button();
            this.PasswordPlaintext_button = new System.Windows.Forms.Button();
            this.DeletePasswordInformation_pictureBox = new System.Windows.Forms.PictureBox();
            this.label = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.PasswordInfo_dataGridView)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeletePasswordInformation_pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // PasswordInfo_dataGridView
            // 
            this.PasswordInfo_dataGridView.BackgroundColor = System.Drawing.SystemColors.Info;
            this.PasswordInfo_dataGridView.ColumnHeadersHeight = 100;
            this.PasswordInfo_dataGridView.Location = new System.Drawing.Point(224, 243);
            this.PasswordInfo_dataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PasswordInfo_dataGridView.Name = "PasswordInfo_dataGridView";
            this.PasswordInfo_dataGridView.RowHeadersWidth = 102;
            this.PasswordInfo_dataGridView.RowTemplate.Height = 40;
            this.PasswordInfo_dataGridView.Size = new System.Drawing.Size(2857, 623);
            this.PasswordInfo_dataGridView.TabIndex = 0;
            this.PasswordInfo_dataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PasswordInfo_dataGridView_CellContentClick);
            // 
            // Edit_button
            // 
            this.Edit_button.BackColor = System.Drawing.SystemColors.Info;
            this.Edit_button.Location = new System.Drawing.Point(3099, 359);
            this.Edit_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Edit_button.Name = "Edit_button";
            this.Edit_button.Size = new System.Drawing.Size(240, 57);
            this.Edit_button.TabIndex = 2;
            this.Edit_button.Text = "Edit";
            this.Edit_button.UseVisualStyleBackColor = false;
            this.Edit_button.Click += new System.EventHandler(this.Edit_button_Click);
            // 
            // Logout_button
            // 
            this.Logout_button.BackColor = System.Drawing.SystemColors.Info;
            this.Logout_button.Location = new System.Drawing.Point(3099, 596);
            this.Logout_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Logout_button.Name = "Logout_button";
            this.Logout_button.Size = new System.Drawing.Size(240, 59);
            this.Logout_button.TabIndex = 5;
            this.Logout_button.Text = "Logout";
            this.Logout_button.UseVisualStyleBackColor = false;
            this.Logout_button.Click += new System.EventHandler(this.Logout_button_Click);
            // 
            // Search_textBox
            // 
            this.Search_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.Search_textBox.Location = new System.Drawing.Point(224, 174);
            this.Search_textBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Search_textBox.Name = "Search_textBox";
            this.Search_textBox.Size = new System.Drawing.Size(2645, 38);
            this.Search_textBox.TabIndex = 6;
            this.Search_textBox.TextChanged += new System.EventHandler(this.Search_textBox_TextChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Info;
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(40, 40);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddPasswordInfo_toolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(3844, 49);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // AddPasswordInfo_toolStripMenuItem
            // 
            this.AddPasswordInfo_toolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddWebsite_toolStripMenuItem,
            this.DesktopApp_toolStripMenuItem,
            this.Game_toolStripMenuItem});
            this.AddPasswordInfo_toolStripMenuItem.Name = "AddPasswordInfo_toolStripMenuItem";
            this.AddPasswordInfo_toolStripMenuItem.Size = new System.Drawing.Size(97, 45);
            this.AddPasswordInfo_toolStripMenuItem.Text = "Add";
            // 
            // AddWebsite_toolStripMenuItem
            // 
            this.AddWebsite_toolStripMenuItem.Name = "AddWebsite_toolStripMenuItem";
            this.AddWebsite_toolStripMenuItem.Size = new System.Drawing.Size(453, 54);
            this.AddWebsite_toolStripMenuItem.Text = "Website";
            this.AddWebsite_toolStripMenuItem.Click += new System.EventHandler(this.AddWebsite_toolStripMenuItem_Click);
            // 
            // DesktopApp_toolStripMenuItem
            // 
            this.DesktopApp_toolStripMenuItem.Name = "DesktopApp_toolStripMenuItem";
            this.DesktopApp_toolStripMenuItem.Size = new System.Drawing.Size(453, 54);
            this.DesktopApp_toolStripMenuItem.Text = "Desktop Application";
            this.DesktopApp_toolStripMenuItem.Click += new System.EventHandler(this.DesktopApp_toolStripMenuItem_Click);
            // 
            // Game_toolStripMenuItem
            // 
            this.Game_toolStripMenuItem.Name = "Game_toolStripMenuItem";
            this.Game_toolStripMenuItem.Size = new System.Drawing.Size(453, 54);
            this.Game_toolStripMenuItem.Text = "Game";
            this.Game_toolStripMenuItem.Click += new System.EventHandler(this.Game_toolStripMenuItem_Click);
            // 
            // SortPasswordInformaation_button
            // 
            this.SortPasswordInformaation_button.BackColor = System.Drawing.SystemColors.Info;
            this.SortPasswordInformaation_button.Location = new System.Drawing.Point(3099, 243);
            this.SortPasswordInformaation_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SortPasswordInformaation_button.Name = "SortPasswordInformaation_button";
            this.SortPasswordInformaation_button.Size = new System.Drawing.Size(240, 52);
            this.SortPasswordInformaation_button.TabIndex = 8;
            this.SortPasswordInformaation_button.Text = "Sort";
            this.SortPasswordInformaation_button.UseVisualStyleBackColor = false;
            this.SortPasswordInformaation_button.Click += new System.EventHandler(this.SortPasswordInformaation_button_Click);
            // 
            // PasswordPlaintext_button
            // 
            this.PasswordPlaintext_button.BackColor = System.Drawing.SystemColors.Info;
            this.PasswordPlaintext_button.Location = new System.Drawing.Point(3099, 473);
            this.PasswordPlaintext_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PasswordPlaintext_button.Name = "PasswordPlaintext_button";
            this.PasswordPlaintext_button.Size = new System.Drawing.Size(240, 74);
            this.PasswordPlaintext_button.TabIndex = 11;
            this.PasswordPlaintext_button.Text = "Show Password";
            this.PasswordPlaintext_button.UseVisualStyleBackColor = false;
            this.PasswordPlaintext_button.Click += new System.EventHandler(this.PasswordPlaintext_button_Click);
            // 
            // DeletePasswordInformation_pictureBox
            // 
            this.DeletePasswordInformation_pictureBox.BackColor = System.Drawing.Color.Transparent;
            this.DeletePasswordInformation_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("DeletePasswordInformation_pictureBox.Image")));
            this.DeletePasswordInformation_pictureBox.Location = new System.Drawing.Point(3143, 734);
            this.DeletePasswordInformation_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DeletePasswordInformation_pictureBox.Name = "DeletePasswordInformation_pictureBox";
            this.DeletePasswordInformation_pictureBox.Size = new System.Drawing.Size(130, 132);
            this.DeletePasswordInformation_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DeletePasswordInformation_pictureBox.TabIndex = 10;
            this.DeletePasswordInformation_pictureBox.TabStop = false;
            this.DeletePasswordInformation_pictureBox.Click += new System.EventHandler(this.DeletePasswordInformation_pictureBox_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.BackColor = System.Drawing.Color.Transparent;
            this.label.ForeColor = System.Drawing.Color.Cornsilk;
            this.label.Location = new System.Drawing.Point(238, 107);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(307, 32);
            this.label.TabIndex = 12;
            this.label.Text = "Seach here by name....";
            // 
            // Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(3844, 967);
            this.Controls.Add(this.label);
            this.Controls.Add(this.PasswordPlaintext_button);
            this.Controls.Add(this.DeletePasswordInformation_pictureBox);
            this.Controls.Add(this.SortPasswordInformaation_button);
            this.Controls.Add(this.Search_textBox);
            this.Controls.Add(this.Logout_button);
            this.Controls.Add(this.Edit_button);
            this.Controls.Add(this.PasswordInfo_dataGridView);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Manager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PasswordInformation";
            this.Load += new System.EventHandler(this.Manager_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PasswordInfo_dataGridView)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DeletePasswordInformation_pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView PasswordInfo_dataGridView;
        private System.Windows.Forms.Button Edit_button;
        private System.Windows.Forms.Button Logout_button;
        private System.Windows.Forms.TextBox Search_textBox;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem AddPasswordInfo_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddWebsite_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DesktopApp_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Game_toolStripMenuItem;
        private System.Windows.Forms.Button SortPasswordInformaation_button;
        private System.Windows.Forms.PictureBox DeletePasswordInformation_pictureBox;
        private System.Windows.Forms.Button PasswordPlaintext_button;
        private System.Windows.Forms.Label label;
    }
}