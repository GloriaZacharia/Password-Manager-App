﻿namespace _18131611
{
    partial class PasswordInformation_label
    {
        public PasswordInformation_label() { }
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddName_label = new System.Windows.Forms.Label();
            this.AddUsername_label = new System.Windows.Forms.Label();
            this.AddWebsiteUrl_label = new System.Windows.Forms.Label();
            this.AddGameDeveloper_label = new System.Windows.Forms.Label();
            this.AddDateCreated_label = new System.Windows.Forms.Label();
            this.AddName_textBox = new System.Windows.Forms.TextBox();
            this.AddUsername_textBox = new System.Windows.Forms.TextBox();
            this.AddWebsiteUrl_textBox = new System.Windows.Forms.TextBox();
            this.AddGameDeveloper_textBox = new System.Windows.Forms.TextBox();
            this.AddDateCreated_textBox = new System.Windows.Forms.TextBox();
            this.AddDateLastUpdated_label = new System.Windows.Forms.Label();
            this.AddDateLastUpdated_textBox = new System.Windows.Forms.TextBox();
            this.SavePasswordInformation_button = new System.Windows.Forms.Button();
            this.AddPassword_label = new System.Windows.Forms.Label();
            this.AddPassword_textBox = new System.Windows.Forms.TextBox();
            this.CancelAdd_button = new System.Windows.Forms.Button();
            this.PasswordType_label = new System.Windows.Forms.Label();
            this.PasswordType_textBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // AddName_label
            // 
            this.AddName_label.AutoSize = true;
            this.AddName_label.BackColor = System.Drawing.Color.Transparent;
            this.AddName_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddName_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.AddName_label.Location = new System.Drawing.Point(241, 164);
            this.AddName_label.Name = "AddName_label";
            this.AddName_label.Size = new System.Drawing.Size(133, 46);
            this.AddName_label.TabIndex = 1;
            this.AddName_label.Text = "Name";
            // 
            // AddUsername_label
            // 
            this.AddUsername_label.AutoSize = true;
            this.AddUsername_label.BackColor = System.Drawing.Color.Transparent;
            this.AddUsername_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddUsername_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.AddUsername_label.Location = new System.Drawing.Point(241, 274);
            this.AddUsername_label.Name = "AddUsername_label";
            this.AddUsername_label.Size = new System.Drawing.Size(239, 46);
            this.AddUsername_label.TabIndex = 2;
            this.AddUsername_label.Text = "Username*";
            // 
            // AddWebsiteUrl_label
            // 
            this.AddWebsiteUrl_label.AutoSize = true;
            this.AddWebsiteUrl_label.BackColor = System.Drawing.Color.Transparent;
            this.AddWebsiteUrl_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddWebsiteUrl_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.AddWebsiteUrl_label.Location = new System.Drawing.Point(241, 481);
            this.AddWebsiteUrl_label.Name = "AddWebsiteUrl_label";
            this.AddWebsiteUrl_label.Size = new System.Drawing.Size(261, 46);
            this.AddWebsiteUrl_label.TabIndex = 4;
            this.AddWebsiteUrl_label.Text = "WebsiteURL";
            // 
            // AddGameDeveloper_label
            // 
            this.AddGameDeveloper_label.AutoSize = true;
            this.AddGameDeveloper_label.BackColor = System.Drawing.Color.Transparent;
            this.AddGameDeveloper_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddGameDeveloper_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.AddGameDeveloper_label.Location = new System.Drawing.Point(239, 589);
            this.AddGameDeveloper_label.Name = "AddGameDeveloper_label";
            this.AddGameDeveloper_label.Size = new System.Drawing.Size(347, 46);
            this.AddGameDeveloper_label.TabIndex = 5;
            this.AddGameDeveloper_label.Text = "Game Developer";
            // 
            // AddDateCreated_label
            // 
            this.AddDateCreated_label.AutoSize = true;
            this.AddDateCreated_label.BackColor = System.Drawing.Color.Transparent;
            this.AddDateCreated_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddDateCreated_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.AddDateCreated_label.Location = new System.Drawing.Point(241, 700);
            this.AddDateCreated_label.Name = "AddDateCreated_label";
            this.AddDateCreated_label.Size = new System.Drawing.Size(281, 46);
            this.AddDateCreated_label.TabIndex = 6;
            this.AddDateCreated_label.Text = "Date Created";
            // 
            // AddName_textBox
            // 
            this.AddName_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.AddName_textBox.Location = new System.Drawing.Point(665, 173);
            this.AddName_textBox.Name = "AddName_textBox";
            this.AddName_textBox.Size = new System.Drawing.Size(592, 38);
            this.AddName_textBox.TabIndex = 7;
            // 
            // AddUsername_textBox
            // 
            this.AddUsername_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.AddUsername_textBox.Location = new System.Drawing.Point(665, 282);
            this.AddUsername_textBox.Name = "AddUsername_textBox";
            this.AddUsername_textBox.Size = new System.Drawing.Size(592, 38);
            this.AddUsername_textBox.TabIndex = 8;
            // 
            // AddWebsiteUrl_textBox
            // 
            this.AddWebsiteUrl_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.AddWebsiteUrl_textBox.Location = new System.Drawing.Point(665, 481);
            this.AddWebsiteUrl_textBox.Name = "AddWebsiteUrl_textBox";
            this.AddWebsiteUrl_textBox.Size = new System.Drawing.Size(592, 38);
            this.AddWebsiteUrl_textBox.TabIndex = 10;
            // 
            // AddGameDeveloper_textBox
            // 
            this.AddGameDeveloper_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.AddGameDeveloper_textBox.Location = new System.Drawing.Point(665, 589);
            this.AddGameDeveloper_textBox.Name = "AddGameDeveloper_textBox";
            this.AddGameDeveloper_textBox.Size = new System.Drawing.Size(592, 38);
            this.AddGameDeveloper_textBox.TabIndex = 11;
            // 
            // AddDateCreated_textBox
            // 
            this.AddDateCreated_textBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem;
            this.AddDateCreated_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.AddDateCreated_textBox.Location = new System.Drawing.Point(665, 694);
            this.AddDateCreated_textBox.Name = "AddDateCreated_textBox";
            this.AddDateCreated_textBox.Size = new System.Drawing.Size(592, 38);
            this.AddDateCreated_textBox.TabIndex = 12;
            // 
            // AddDateLastUpdated_label
            // 
            this.AddDateLastUpdated_label.AutoSize = true;
            this.AddDateLastUpdated_label.BackColor = System.Drawing.Color.Transparent;
            this.AddDateLastUpdated_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddDateLastUpdated_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.AddDateLastUpdated_label.Location = new System.Drawing.Point(241, 812);
            this.AddDateLastUpdated_label.Name = "AddDateLastUpdated_label";
            this.AddDateLastUpdated_label.Size = new System.Drawing.Size(383, 46);
            this.AddDateLastUpdated_label.TabIndex = 13;
            this.AddDateLastUpdated_label.Text = "Date Last Updated";
            // 
            // AddDateLastUpdated_textBox
            // 
            this.AddDateLastUpdated_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.AddDateLastUpdated_textBox.Location = new System.Drawing.Point(665, 823);
            this.AddDateLastUpdated_textBox.Name = "AddDateLastUpdated_textBox";
            this.AddDateLastUpdated_textBox.Size = new System.Drawing.Size(592, 38);
            this.AddDateLastUpdated_textBox.TabIndex = 14;
            // 
            // SavePasswordInformation_button
            // 
            this.SavePasswordInformation_button.BackColor = System.Drawing.Color.LemonChiffon;
            this.SavePasswordInformation_button.Location = new System.Drawing.Point(852, 1014);
            this.SavePasswordInformation_button.Name = "SavePasswordInformation_button";
            this.SavePasswordInformation_button.Size = new System.Drawing.Size(187, 85);
            this.SavePasswordInformation_button.TabIndex = 15;
            this.SavePasswordInformation_button.Text = "Save";
            this.SavePasswordInformation_button.UseVisualStyleBackColor = false;
            this.SavePasswordInformation_button.Click += new System.EventHandler(this.SavePasswordInformation_button_Click);
            this.SavePasswordInformation_button.Validated += new System.EventHandler(this.SavePasswordInformation_button_Click);
            // 
            // AddPassword_label
            // 
            this.AddPassword_label.AutoSize = true;
            this.AddPassword_label.BackColor = System.Drawing.Color.Transparent;
            this.AddPassword_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddPassword_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.AddPassword_label.Location = new System.Drawing.Point(241, 370);
            this.AddPassword_label.Name = "AddPassword_label";
            this.AddPassword_label.Size = new System.Drawing.Size(220, 46);
            this.AddPassword_label.TabIndex = 3;
            this.AddPassword_label.Text = "Password*";
            // 
            // AddPassword_textBox
            // 
            this.AddPassword_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.AddPassword_textBox.Location = new System.Drawing.Point(665, 370);
            this.AddPassword_textBox.Name = "AddPassword_textBox";
            this.AddPassword_textBox.Size = new System.Drawing.Size(592, 38);
            this.AddPassword_textBox.TabIndex = 9;
            // 
            // CancelAdd_button
            // 
            this.CancelAdd_button.BackColor = System.Drawing.Color.LemonChiffon;
            this.CancelAdd_button.Location = new System.Drawing.Point(852, 1121);
            this.CancelAdd_button.Name = "CancelAdd_button";
            this.CancelAdd_button.Size = new System.Drawing.Size(187, 82);
            this.CancelAdd_button.TabIndex = 16;
            this.CancelAdd_button.Text = "Cancel";
            this.CancelAdd_button.UseVisualStyleBackColor = false;
            this.CancelAdd_button.Click += new System.EventHandler(this.CancelAdd_button_Click);
            // 
            // PasswordType_label
            // 
            this.PasswordType_label.AutoSize = true;
            this.PasswordType_label.BackColor = System.Drawing.Color.Transparent;
            this.PasswordType_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordType_label.ForeColor = System.Drawing.Color.LemonChiffon;
            this.PasswordType_label.Location = new System.Drawing.Point(241, 924);
            this.PasswordType_label.Name = "PasswordType_label";
            this.PasswordType_label.Size = new System.Drawing.Size(112, 44);
            this.PasswordType_label.TabIndex = 17;
            this.PasswordType_label.Text = "Type";
            // 
            // PasswordType_textBox
            // 
            this.PasswordType_textBox.BackColor = System.Drawing.SystemColors.Info;
            this.PasswordType_textBox.ForeColor = System.Drawing.SystemColors.WindowText;
            this.PasswordType_textBox.Location = new System.Drawing.Point(665, 929);
            this.PasswordType_textBox.Name = "PasswordType_textBox";
            this.PasswordType_textBox.Size = new System.Drawing.Size(592, 38);
            this.PasswordType_textBox.TabIndex = 18;
            // 
            // PasswordInformation_label
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(240F, 240F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1636, 1259);
            this.Controls.Add(this.PasswordType_textBox);
            this.Controls.Add(this.PasswordType_label);
            this.Controls.Add(this.CancelAdd_button);
            this.Controls.Add(this.SavePasswordInformation_button);
            this.Controls.Add(this.AddDateLastUpdated_textBox);
            this.Controls.Add(this.AddDateLastUpdated_label);
            this.Controls.Add(this.AddDateCreated_textBox);
            this.Controls.Add(this.AddGameDeveloper_textBox);
            this.Controls.Add(this.AddWebsiteUrl_textBox);
            this.Controls.Add(this.AddPassword_textBox);
            this.Controls.Add(this.AddUsername_textBox);
            this.Controls.Add(this.AddName_textBox);
            this.Controls.Add(this.AddDateCreated_label);
            this.Controls.Add(this.AddGameDeveloper_label);
            this.Controls.Add(this.AddWebsiteUrl_label);
            this.Controls.Add(this.AddPassword_label);
            this.Controls.Add(this.AddUsername_label);
            this.Controls.Add(this.AddName_label);
            this.Name = "PasswordInformation_label";
            this.Text = "PasswordInformation";
            this.Load += new System.EventHandler(this.PasswordInformation_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label AddName_label;
        private System.Windows.Forms.Label AddUsername_label;
        private System.Windows.Forms.Label AddWebsiteUrl_label;
        private System.Windows.Forms.Label AddGameDeveloper_label;
        private System.Windows.Forms.Label AddDateCreated_label;
        private System.Windows.Forms.TextBox AddName_textBox;
        private System.Windows.Forms.TextBox AddUsername_textBox;
        private System.Windows.Forms.TextBox AddDateCreated_textBox;
        private System.Windows.Forms.Label AddDateLastUpdated_label;
        private System.Windows.Forms.TextBox AddDateLastUpdated_textBox;
        public System.Windows.Forms.TextBox AddGameDeveloper_textBox;
        public System.Windows.Forms.TextBox AddWebsiteUrl_textBox;
        private System.Windows.Forms.Button SavePasswordInformation_button;
        private System.Windows.Forms.Label AddPassword_label;
        public System.Windows.Forms.TextBox AddPassword_textBox;
        private System.Windows.Forms.Button CancelAdd_button;
        private System.Windows.Forms.Label PasswordType_label;
        public System.Windows.Forms.TextBox PasswordType_textBox;
    }
}