﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _18131611
{
    public partial class Game : PasswordInformation_label
    {
        private string type = "Game";
        public Game(int userid): base(userid)
        {
            InitializeComponent();
            userId = userid;
            PasswordType_textBox.Text = type;
        }

        private void Game_Load(object sender, EventArgs e)
        {
            AddWebsiteUrl_textBox.Enabled = false;
        }
    }
}
