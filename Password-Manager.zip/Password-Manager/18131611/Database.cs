﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.OleDb;
using System.Data;

namespace _18131611
{

    class Database
    {
        //----------------FOR CONNECTION TO DATABASE------------------//

        //Create an oleDbConnection
        private OleDbConnection DBConnection = new OleDbConnection();

        //Creat a data adapetr(to get values from the access table)
        private OleDbDataAdapter DataAdapter;
        private OleDbCommand cmd;
        //Create a local data table to hold the values of access table
        private DataTable userDataTable = new DataTable();
        private DataTable passswordInformationDataTable = new DataTable();
        
        public DataRow[] getUserRows()
        {
            //set path of DB file
            DBConnection.ConnectionString = @"Provider=Microsoft.ACE.OleDB.12.0;Data Source=Password Manager.accdb";

            //Open Connection to DB
            DBConnection.Open();
            //Tell Data Adaptor what to get form which table in out MS Access DB
            DataAdapter = new OleDbDataAdapter("Select * From Users", DBConnection);

            //Fill the tabel with all user information
            DataAdapter.Fill(userDataTable);

            DataRow[] rows = userDataTable.Select(); //populate the row 
            DBConnection.Close(); // close connection
            return rows;
        }
        public DataTable getPassInfoRows(int userId, bool isAdmin)
        {
            //set path of DB file
            DBConnection.ConnectionString = @"Provider=Microsoft.ACE.OleDB.12.0;Data Source=Password Manager.accdb";

            //Open Connection to DB
            DBConnection.Open();
           
            try
            {
                if(isAdmin) //if the current user is an admin
                {
                    DataAdapter = new OleDbDataAdapter("Select * From [PasswordInformation]", DBConnection); //get all password information for all users
                    DataAdapter.Fill(passswordInformationDataTable); //populate the table with this information
                }
                else //if the current user is not an admin
                {
                    DataAdapter = new OleDbDataAdapter("Select * From [PasswordInformation] where [UserId]=" + userId + "", DBConnection); // get only the information related to that user
                    DataAdapter.Fill(passswordInformationDataTable); // fill the table with the information
                }

                return passswordInformationDataTable; // return the selected password information

            }
            catch (OleDbException ex)
            {
                Console.WriteLine(ex.Message);
                DBConnection.Close();
                return passswordInformationDataTable;

            }

        }
        public void insertNewUser(DataTable newTable)
        {
            DBConnection.ConnectionString = @"Provider=Microsoft.ACE.OleDB.12.0;Data Source=Password Manager.accdb";

            //populate the table with the new user information
            DataRow row = newTable.Rows[0];
            string Fname = (row["Fname"]).ToString();
            string Sname = (row["Sname"]).ToString();
            string address = (row["Address"]).ToString();
            string username = (row["Username"]).ToString();
            string password = (row["Password"]).ToString();
            
            //create the query string
            string my_querry = "INSERT INTO [Users] ([First Name],[Second Name],[Address],[Username],[Password])VALUES(@Fname ,@Sname,@address,@username,@password)";
            cmd = new OleDbCommand(my_querry,DBConnection);
            cmd.Connection=DBConnection;
            DBConnection.Open(); //open connection

            if (DBConnection.State == ConnectionState.Open) //if connection is made
             {
                    //insert new user information to the database
                    cmd.Parameters.Add("@First Name", OleDbType.VarChar).Value = Fname;
                    cmd.Parameters.Add("@Second Name", OleDbType.VarChar).Value = Sname;
                    cmd.Parameters.Add("@Address", OleDbType.VarChar).Value = address;
                    cmd.Parameters.Add("@Username", OleDbType.VarChar).Value = username;
                    cmd.Parameters.Add("@Password", OleDbType.VarChar).Value = password;

                try
                {
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Data added");
                    DBConnection.Close();

                }
                catch (OleDbException ex)
                {
                    Console.WriteLine(ex.Message);
                    DBConnection.Close();
                }
            }
            else
            {
                Console.Write("Connection failed!");
            }
           

        }
        public void addPassworInformation(DataTable newTable)
        {
            DBConnection.ConnectionString = @"Provider=Microsoft.ACE.OleDB.12.0;Data Source=Password Manager.accdb";

            DataRow row = newTable.Rows[0];
            string name = (row["Name"]).ToString();
            string username = (row["Username"]).ToString();
            string password = (row["Password"]).ToString();
            string websiteUrl = (row["WebsiteUrl"]).ToString();
            string gameDeveloper = (row["GameDeveloper"]).ToString();
            string dateCreated = (row["DateCreated"]).ToString();
            string dateLastUpdated = (row["DateLastUpdated"]).ToString();
            string type = (row["Type"]).ToString();
            int userId = row.Field<int>("UserId");
            string my_querry = "INSERT INTO [PasswordInformation] ([Name],[Username],[Password],[WebsiteUrl],[Game Developer],[Date Created],[Date Last Updated],[Type],[UserId])VALUES(@name,@username,@password,@websiteUrl,@gameDeveloper,@dateCreated,@dateLastUpdated,@type,@userId)";

            cmd = new OleDbCommand(my_querry, DBConnection);
            cmd.Connection = DBConnection;
            DBConnection.Open();

            if (DBConnection.State == ConnectionState.Open)
            {
                cmd.Parameters.Add("@Name", OleDbType.VarChar).Value = name;
                cmd.Parameters.Add("@Username", OleDbType.VarChar).Value = username;
                cmd.Parameters.Add("@Password", OleDbType.VarChar).Value = password;
                cmd.Parameters.Add("@WebsiteUrl", OleDbType.VarChar).Value = websiteUrl;
                cmd.Parameters.Add("@Game Developer", OleDbType.VarChar).Value = gameDeveloper;
                cmd.Parameters.Add("@Date Created", OleDbType.VarChar).Value = dateCreated;
                cmd.Parameters.Add("@Date Last Updated", OleDbType.VarChar).Value = dateLastUpdated;
                cmd.Parameters.Add("@Type", OleDbType.VarChar).Value = type;
                cmd.Parameters.Add("@UserId", OleDbType.Integer).Value = userId;
                Console.WriteLine("Integer area");

                try
                {
                    cmd.ExecuteNonQuery();
                    DBConnection.Close();

                }
                catch (OleDbException ex)
                {
                    Console.WriteLine(ex.Message);
                    DBConnection.Close();
                }
            }
            else
            {
                Console.Write("Connection failed!");
            }


        }
        public void removePasswordInformation (int itemId)
        {
            DBConnection.ConnectionString = @"Provider=Microsoft.ACE.OleDB.12.0;Data Source=Password Manager.accdb";
            Console.WriteLine(itemId);
            DBConnection.Open();
            OleDbCommand cmd = new OleDbCommand("DELETE FROM PasswordInformation WHERE [ID] ="+ itemId +"", DBConnection);

            try
            {
                cmd.ExecuteNonQuery();
                DBConnection.Close();


            }
            catch (OleDbException ex)
            {
                Console.WriteLine(ex.Message);
                DBConnection.Close();
            }

        }
        public void updatePasswordInformation(DataTable updatedTable)
        {
            DBConnection.ConnectionString = @"Provider=Microsoft.ACE.OleDB.12.0;Data Source=Password Manager.accdb";
            DBConnection.Open();


            DataRow row = updatedTable.Rows[0];
            int Id = row.Field<int>("Id");
            string name = (row["Name"]).ToString();
            string username = (row["Username"]).ToString();
            string password = (row["Password"]).ToString();
            string websiteUrl = (row["WebsiteUrl"]).ToString();
            string gameDeveloper = (row["GameDeveloper"]).ToString();
            string dateCreated = (row["DateCreated"]).ToString();
            string dateLastUpdated = (row["DateLastUpdated"]).ToString();
            string type = (row["Type"]).ToString();
            int userId = row.Field<int>("UserId");

            cmd = new OleDbCommand("UPDATE [PasswordInformation] SET [Name]='" + name + "',[Username]='" + username + "',[Password]='" + password + "',[WebsiteUrl]= '" + websiteUrl + "',[Game Developer]= '" + gameDeveloper + "',[Date Created]= '" + dateCreated + "',[Date Last Updated]= '" + dateLastUpdated + "',[Type]='"+ type +"', [UserId]= " + userId + " WHERE [ID] =" + Id + "", DBConnection);

            
            if (DBConnection.State == ConnectionState.Open)
            {
                cmd.Parameters.AddWithValue("@Name", OleDbType.VarChar).Value = name;
                cmd.Parameters.AddWithValue("@Username", OleDbType.VarChar).Value = username;
                cmd.Parameters.AddWithValue("@Password", OleDbType.VarChar).Value = password;
                cmd.Parameters.AddWithValue("@WebsiteUrl", OleDbType.VarChar).Value = websiteUrl;
                cmd.Parameters.AddWithValue("@Game Developer", OleDbType.VarChar).Value = gameDeveloper;
                cmd.Parameters.AddWithValue("@Date Created", OleDbType.VarChar).Value = dateCreated;
                cmd.Parameters.AddWithValue("@Date Last Updated", OleDbType.VarChar).Value = dateLastUpdated;
                cmd.Parameters.Add("@Type", OleDbType.VarChar).Value = type;
                cmd.Parameters.AddWithValue("@UserId", OleDbType.Integer).Value = userId;
                cmd.Connection = DBConnection;
                try
                {
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Record updated");
                    DBConnection.Close();


                }
                catch (OleDbException ex)
                {
                    Console.WriteLine(ex.Message);
                    DBConnection.Close();
                }
            }
            else
            {
                Console.Write("Connection failed!");
            }
        }
        public DataTable sortPasswordInformation(int userId)
        {
            DBConnection.ConnectionString = @"Provider=Microsoft.ACE.OleDB.12.0;Data Source=Password Manager.accdb";
            DBConnection.Open();
         
            try
            {
                DataAdapter = new OleDbDataAdapter("Select * From [PasswordInformation] where [UserId]=" + userId + " order by [Date Last Updated] desc", DBConnection);
                DataAdapter.Fill(passswordInformationDataTable);
                return passswordInformationDataTable;
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return passswordInformationDataTable;

            }

        }
        
    }
}
