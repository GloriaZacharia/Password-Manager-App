﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18131611
{
    class RandomPasswordGenerator
    {
        private static int MAX = 26; 
        public string generateRandomPassword(int n)
        {

            char[] alphabet ={ 'a', 'b', 'c', 'd', 'e', 'f', 'g','h', 'i', 'j', 'k', 'l', 'm', 'n','o', 'p', 'q', 'r', 's', 't', 'u','v', 'w', 'x', 'y', 'z' };

            Random random = new Random();
            string output = "";
            for(int i=0;i<n;i++) 
            {
                output = output + alphabet[(int)(random.Next(0,MAX))]; 
            }
            return output;
        }
    }
}
