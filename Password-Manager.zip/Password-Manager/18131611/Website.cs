﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace _18131611
{
    public partial class Website : _18131611.PasswordInformation_label
    {
        private string type = "Website";

        public Website(int userid): base(userid)
        {
            InitializeComponent();
            userId = userid;
            PasswordType_textBox.Text = type;
        }

        private void Website_Load(object sender, EventArgs e)
        {

            AddGameDeveloper_textBox.Enabled = false;
        }
    }
}
