﻿namespace _18131611
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LoginUsername_label = new System.Windows.Forms.Label();
            this.LoginPassword_label = new System.Windows.Forms.Label();
            this.LoginUsername_textBox = new System.Windows.Forms.TextBox();
            this.LoginPassword_textBox = new System.Windows.Forms.TextBox();
            this.Login_button = new System.Windows.Forms.Button();
            this.LoginError_label = new System.Windows.Forms.Label();
            this.Register_linkLabel = new System.Windows.Forms.LinkLabel();
            this.ExitLogin_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LoginUsername_label
            // 
            this.LoginUsername_label.AutoSize = true;
            this.LoginUsername_label.BackColor = System.Drawing.Color.Transparent;
            this.LoginUsername_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginUsername_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.LoginUsername_label.Location = new System.Drawing.Point(82, 116);
            this.LoginUsername_label.Name = "LoginUsername_label";
            this.LoginUsername_label.Size = new System.Drawing.Size(221, 46);
            this.LoginUsername_label.TabIndex = 0;
            this.LoginUsername_label.Text = "Username";
            // 
            // LoginPassword_label
            // 
            this.LoginPassword_label.AutoSize = true;
            this.LoginPassword_label.BackColor = System.Drawing.Color.Transparent;
            this.LoginPassword_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginPassword_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.LoginPassword_label.Location = new System.Drawing.Point(82, 284);
            this.LoginPassword_label.Name = "LoginPassword_label";
            this.LoginPassword_label.Size = new System.Drawing.Size(215, 46);
            this.LoginPassword_label.TabIndex = 1;
            this.LoginPassword_label.Text = "Password";
            // 
            // LoginUsername_textBox
            // 
            this.LoginUsername_textBox.BackColor = System.Drawing.Color.Ivory;
            this.LoginUsername_textBox.Location = new System.Drawing.Point(373, 116);
            this.LoginUsername_textBox.Name = "LoginUsername_textBox";
            this.LoginUsername_textBox.Size = new System.Drawing.Size(457, 38);
            this.LoginUsername_textBox.TabIndex = 2;
            this.LoginUsername_textBox.Text = "GabrielS";
            // 
            // LoginPassword_textBox
            // 
            this.LoginPassword_textBox.BackColor = System.Drawing.Color.Ivory;
            this.LoginPassword_textBox.Location = new System.Drawing.Point(359, 284);
            this.LoginPassword_textBox.Name = "LoginPassword_textBox";
            this.LoginPassword_textBox.Size = new System.Drawing.Size(471, 38);
            this.LoginPassword_textBox.TabIndex = 3;
            this.LoginPassword_textBox.Text = "Green";
            // 
            // Login_button
            // 
            this.Login_button.BackColor = System.Drawing.Color.Cornsilk;
            this.Login_button.Location = new System.Drawing.Point(459, 540);
            this.Login_button.Name = "Login_button";
            this.Login_button.Size = new System.Drawing.Size(216, 99);
            this.Login_button.TabIndex = 4;
            this.Login_button.Text = "Login";
            this.Login_button.UseVisualStyleBackColor = false;
            this.Login_button.Click += new System.EventHandler(this.Login_button_Click);
            // 
            // LoginError_label
            // 
            this.LoginError_label.AutoSize = true;
            this.LoginError_label.BackColor = System.Drawing.SystemColors.Info;
            this.LoginError_label.ForeColor = System.Drawing.Color.DeepPink;
            this.LoginError_label.Location = new System.Drawing.Point(359, 452);
            this.LoginError_label.Name = "LoginError_label";
            this.LoginError_label.Size = new System.Drawing.Size(0, 32);
            this.LoginError_label.TabIndex = 5;
            // 
            // Register_linkLabel
            // 
            this.Register_linkLabel.ActiveLinkColor = System.Drawing.Color.Aqua;
            this.Register_linkLabel.AutoSize = true;
            this.Register_linkLabel.BackColor = System.Drawing.Color.Transparent;
            this.Register_linkLabel.LinkColor = System.Drawing.Color.Gold;
            this.Register_linkLabel.Location = new System.Drawing.Point(467, 702);
            this.Register_linkLabel.Name = "Register_linkLabel";
            this.Register_linkLabel.Size = new System.Drawing.Size(185, 32);
            this.Register_linkLabel.TabIndex = 6;
            this.Register_linkLabel.TabStop = true;
            this.Register_linkLabel.Text = "Register here";
            this.Register_linkLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.Register_linkLabel_LinkClicked);
            // 
            // ExitLogin_button
            // 
            this.ExitLogin_button.BackColor = System.Drawing.Color.Cornsilk;
            this.ExitLogin_button.Location = new System.Drawing.Point(1373, 12);
            this.ExitLogin_button.Name = "ExitLogin_button";
            this.ExitLogin_button.Size = new System.Drawing.Size(162, 54);
            this.ExitLogin_button.TabIndex = 7;
            this.ExitLogin_button.Text = "Exit";
            this.ExitLogin_button.UseVisualStyleBackColor = false;
            this.ExitLogin_button.Click += new System.EventHandler(this.ExitLogin_button_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1550, 999);
            this.Controls.Add(this.ExitLogin_button);
            this.Controls.Add(this.Register_linkLabel);
            this.Controls.Add(this.LoginError_label);
            this.Controls.Add(this.Login_button);
            this.Controls.Add(this.LoginPassword_textBox);
            this.Controls.Add(this.LoginUsername_textBox);
            this.Controls.Add(this.LoginPassword_label);
            this.Controls.Add(this.LoginUsername_label);
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LoginUsername_label;
        private System.Windows.Forms.Label LoginPassword_label;
        private System.Windows.Forms.TextBox LoginUsername_textBox;
        private System.Windows.Forms.TextBox LoginPassword_textBox;
        private System.Windows.Forms.Button Login_button;
        private System.Windows.Forms.Label LoginError_label;
        private System.Windows.Forms.LinkLabel Register_linkLabel;
        private System.Windows.Forms.Button ExitLogin_button;
    }
}