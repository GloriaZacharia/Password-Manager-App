﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _18131611
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void Register_button_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(RegisterUsername_textBox.Text))  //If a prefered username value is not provided
            {
                MessageBox.Show("Please input all the required fields", "Warning", MessageBoxButtons.OK);

            }
            else if(String.IsNullOrEmpty(RegisterPassword_textBox.Text)) //if aprefered password value is not provided
            {
                MessageBox.Show("Please input all the required fields", "Warning", MessageBoxButtons.OK);

            }
            else  //If all the reuired fields are provided
            { 
                DataTable newUserData = new DataTable(); //a table to hold all the information of the new user 
                newUserData.Columns.Add("Fname", typeof(string));
                newUserData.Columns.Add("Sname", typeof(string));
                newUserData.Columns.Add("Address", typeof(string));
                newUserData.Columns.Add("Username", typeof(string));
                newUserData.Columns.Add("Password", typeof(string));

                Database database = new Database();
                DataRow[] rows = database.getUserRows(); //Get all the available user informations
                for (int i = 0; i < rows.Length; i++) //As long as we have not gone through all the user information
                {
                    if (String.Equals(rows[i]["Username"].ToString(), RegisterUsername_textBox.Text)) //If the chosen username already exists
                    {
                        DialogResult choice = MessageBox.Show("This username is not available.Please enter another one", "Title", MessageBoxButtons.OKCancel); //hrow an error message
                        if (choice == DialogResult.Cancel) //If the user chooses to abort the process
                        {
                            this.DialogResult = DialogResult.OK; //close the page and stop the loop
                            break;
                        }
                        else if (choice == DialogResult.OK) //If the user wishes to select a different username
                        {
                            this.Show(); //redisplay the register page and restart the process
                            break;
                        }

                    }
                    else if (!String.Equals(rows[i]["Username"].ToString(), RegisterUsername_textBox.Text)) //If the prefered username does not exist in the system
                    {
                        if (i == rows.Length - 1) //If we have gone through all the user records in the system
                        {
                            newUserData.Rows.Add(RegisterFName_textBox.Text, RegisterSName_textBox.Text, RegisterAddress_textBox.Text, RegisterUsername_textBox.Text, RegisterPassword_textBox.Text); //populate the table with the new user information
                            database.insertNewUser(newUserData); //Insert them into the system
                            this.DialogResult = DialogResult.OK; //return to the login page
                        }
                    }

                }
            }

        }

        private void Register_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.image1;
        }

        private void CancelRegister_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
