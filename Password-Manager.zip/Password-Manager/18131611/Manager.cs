﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _18131611
{
    public partial class Manager : Form
    {
        private bool isAdmin=false; // a variable to tell the system what icons to disable
        private int userId = 0;
        public Manager(bool isadmin, int userid)
        {
            InitializeComponent();
            isAdmin = isadmin;
            userId = userid;

        }

        private void AddWebsite_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide(); //hide this page
            Website web = new Website(userId);
            web.ShowDialog(); //load the website page
            this.Show();  //redisplay this page when the website page returns a response
            getPasswordInformation(); //reload the user password information

        }

        private void Manager_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.image1;
            this.PasswordInfo_dataGridView.RowTemplate.Height = 20;
            PasswordInfo_dataGridView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            PasswordInfo_dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            getPasswordInformation();

            if(isAdmin) //if the current user is an admin
            {
                AddPasswordInfo_toolStripMenuItem.Enabled = false; //disable the functionality to add passwords
               
            }

            if (PasswordInfo_dataGridView.Rows.Count == 0) // if there arev no passwords to display
            {
                PasswordPlaintext_button.Enabled = false; //display the function to shoe passwords in plain text
            }
            else //If there are password information displayed 
            {
                PasswordPlaintext_button.Enabled = true; //allow to view the password in plain text
            }

        }
        private void getPasswordInformation() //function to get all the password information related to a user
        {
            Database database = new Database();

            DataTable passwordData = database.getPassInfoRows(userId, isAdmin); //store the passwords in a table
            int index = passwordData.Columns.Count; 
            passwordData.Columns.RemoveAt(index-1); //remove the 'userId' varible from the table since it does not need to be displayed
            passwordData.AcceptChanges(); //commit the changes to the table
            try
            {
                PasswordInfo_dataGridView.DataSource = passwordData; //Display all the passwords related to the user
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void PasswordInfo_dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            PasswordInfo_dataGridView.BeginEdit(true);  
            PasswordInfo_dataGridView.RowTemplate.Height = 40;
        }
       
        private void DesktopApp_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide(); //hide the current page
            DesktopApplication desktop = new DesktopApplication(userId);
            desktop.ShowDialog(); //load up the desktop page
            this.Show(); //redisplay this page
            getPasswordInformation(); //reload the password information of the user
        }

        private void Game_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Game game = new Game(userId);
            game.ShowDialog();
            this.Show();
            getPasswordInformation();
        }

        private void DeletePasswordInformation_pictureBox_Click(object sender, EventArgs e)
        {
            if (PasswordInfo_dataGridView.SelectedRows.Count <= 0) //If there is no row selected
            {
                MessageBox.Show("Please select the item", "Error", MessageBoxButtons.OK);
            }
            else //if one or more rows are selected
            {
                DialogResult choice = MessageBox.Show("Are you sure you want to delete this item/s?", "Warning", MessageBoxButtons.OKCancel); //confirm with the user if they really wish to delete the information/s
                if (choice == DialogResult.OK) //If the user confirms
                {
                    Database database = new Database();
                    for (int i = 0; i < PasswordInfo_dataGridView.SelectedRows.Count; i++) //Go through each selected row
                    {
                        DataGridViewRow selectedRow = PasswordInfo_dataGridView.SelectedRows[i]; //get the first row
                        int selectedItemId = (int)selectedRow.Cells["ID"].Value; //get the ID value of the selected row
                        database.removePasswordInformation(selectedItemId); //delete it from the database
                    }
                    foreach(DataGridViewRow row in PasswordInfo_dataGridView.SelectedRows) //Remove the selected rows form the display
                    {
                        PasswordInfo_dataGridView.Rows.RemoveAt(row.Index);

                    }

                }
            }
        }

        private void Edit_button_Click(object sender, EventArgs e)
        {
            if(PasswordInfo_dataGridView.SelectedRows.Count>1) //If more than one rows are selected
            {
                MessageBox.Show("Please select only one item to edit", "Warning", MessageBoxButtons.OK);
            }
            else if(PasswordInfo_dataGridView.SelectedRows.Count <=0 ) //if no row is selected
            {
                MessageBox.Show("Please select an item to edit", "Warning", MessageBoxButtons.OK);

            }  
            else //if only one row is selected
            {
                DialogResult choice = MessageBox.Show("Are you sure you want to edit?", "", MessageBoxButtons.YesNo); //confirm with the user if they really wish to edit
                if(choice==DialogResult.Yes)
                {
                   //create a table to store the new edited information
                    DataTable editPasswordInfo = new DataTable();
                    editPasswordInfo.Columns.Add("Id", typeof(int));
                    editPasswordInfo.Columns.Add("Name", typeof(string));
                    editPasswordInfo.Columns.Add("Username", typeof(string));
                    editPasswordInfo.Columns.Add("Password", typeof(string));
                    editPasswordInfo.Columns.Add("WebsiteUrl", typeof(string));
                    editPasswordInfo.Columns.Add("GameDeveloper", typeof(string));
                    editPasswordInfo.Columns.Add("DateCreated", typeof(string));
                    editPasswordInfo.Columns.Add("DateLastUpdated", typeof(string));
                    editPasswordInfo.Columns.Add("Type", typeof(string));
                    editPasswordInfo.Columns.Add("UserId", typeof(int));

                    String text;
                    if (PasswordInfo_dataGridView.CurrentCell.ColumnIndex==3) //if the editted cell is the password cell
                    {
                        EncryptDecrypt encrypt = new EncryptDecrypt();
                        text = encrypt.encryptdecrypt((PasswordInfo_dataGridView.SelectedRows[0].Cells[3].Value).ToString()); //encrypt the new password
                    }
                    else 
                    {
                        text = PasswordInfo_dataGridView.SelectedRows[0].Cells[3].Value.ToString();
                    }
                    editPasswordInfo.Rows.Add((int)PasswordInfo_dataGridView.SelectedRows[0].Cells[0].Value, PasswordInfo_dataGridView.SelectedRows[0].Cells[1].Value, PasswordInfo_dataGridView.SelectedRows[0].Cells[2].Value, text, PasswordInfo_dataGridView.SelectedRows[0].Cells[4].Value, PasswordInfo_dataGridView.SelectedRows[0].Cells[5].Value, PasswordInfo_dataGridView.SelectedRows[0].Cells[6].Value, DateTime.Now.ToString(),PasswordInfo_dataGridView.SelectedRows[0].Cells[8].Value,userId); //populate table
                    Database db = new Database();
                    db.updatePasswordInformation(editPasswordInfo); //modify the information in the database
                }
            }
        }

        private void Search_textBox_TextChanged(object sender, EventArgs e)
        {
            string searchInput = Search_textBox.Text; //get the string to search
            try
            {
                Database db = new Database();
                DataTable searchData = db.getPassInfoRows(userId,isAdmin); //get all the password information related to the user
                var a = from row in searchData.AsEnumerable() where row[1].ToString().Contains(searchInput) select row; //get the row/s which matches the user input

                if (a.Count() == 0) // if no rows are found
                {
                    PasswordInfo_dataGridView.DataSource = searchData; //display all the password information

                }
                else //If found then display the all data related to the search data
                {
                    PasswordInfo_dataGridView.DataSource = a.CopyToDataTable();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SortPasswordInformaation_button_Click(object sender, EventArgs e)
        {
            Database db = new Database();
            DataTable sortedData = db.sortPasswordInformation(userId); //get a sorted version of the password information related to the user from the database
            int index = sortedData.Columns.Count; //Get the number of columns of the sorted data
            sortedData.Columns.RemoveAt(index - 1); //remove the 'userId' column
            sortedData.AcceptChanges(); //commit the chabges to the table
            try
            {
                PasswordInfo_dataGridView.DataSource = sortedData; //display the sorted data
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void PasswordPlaintext_button_Click(object sender, EventArgs e)
        {
            if (PasswordInfo_dataGridView.SelectedRows.Count > 1) //if there are more than one rows selected
            {
                MessageBox.Show("Please select one item only", "Warning", MessageBoxButtons.OK);
            }
            else if(PasswordInfo_dataGridView.SelectedRows.Count<=0) //if no row is selected
            {
                MessageBox.Show("Please select an item", "Warning", MessageBoxButtons.OK);

            }
            else //if only one row is selected
            {
                DataGridViewRow selectedRow = PasswordInfo_dataGridView.SelectedRows[0]; //Get the selected row
                int index = PasswordInfo_dataGridView.SelectedRows[0].Index; //get the position of the selected row
                string text=(PasswordInfo_dataGridView.Rows[index].Cells[3].Value).ToString(); //get the value of the password 
                EncryptDecrypt decrypt = new EncryptDecrypt();
                text = decrypt.encryptdecrypt(text); //decrypt the password
                PasswordInfo_dataGridView.Rows[index].Cells[3].Value = text; //deisplay the decrypted text
            }
        }

        private void Logout_button_Click(object sender, EventArgs e)
        {
            isAdmin = false;
            userId = 0;
            this.Close();
            Login login = new Login();
            login.Show();
        }
    }
}
