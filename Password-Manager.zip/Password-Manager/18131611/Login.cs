﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _18131611
{
    public partial class Login : Form
    {

        public Login()
        {
            InitializeComponent();
        }
        
        
        private void Login_button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(LoginUsername_textBox.Text) || string.IsNullOrEmpty(LoginPassword_textBox.Text))//if either the username or password is not provided
            {
                MessageBox.Show("Please enter complete details", "Tiltle", MessageBoxButtons.OK);
            }
            else //if both username and password are provided
            {
                Database database = new Database();
                DataRow[] rows = database.getUserRows(); //get all users information
                for (int i = 0; i < rows.Length; i++) //as long as we have not gone through all users in the system
                {
                    if(LoginUsername_textBox.Text == (rows[i]["Username"]).ToString()) //If the username matches the one in the records
                    {
                        if(LoginPassword_textBox.Text == (rows[i]["Password"]).ToString()) //If the password related to that username matches the one int he record
                        {
                            if (Convert.ToBoolean(rows[i]["Is Admin"])) //If the verified user is and admin
                            {
                                this.Hide();
                                Manager manager = new Manager(true,(int)rows[i]["ID"]); //load up the view page with all passwords of all users
                                manager.Show();
                                break;
                            }
                            else //If the verified user is not an admin
                            {
                                this.Hide();
                                Manager manager = new Manager(false, (int)rows[i]["ID"]); //load up the view page with password information of that specific user.
                                manager.Show();
                                break;

                            }
                        }
                        else if(LoginPassword_textBox.Text!= (rows[i]["Password"]).ToString()) //If the provides password is incorrect
                        {
                            this.LoginError_label.ForeColor = Color.Red;
                            this.LoginError_label.Text = "Error!!Incorrect username or password";
                            break;
                        }
                    }
                    else if(LoginUsername_textBox.Text != (rows[i]["Username"]).ToString() && i==rows.Length-1) //If the provided username is not found
                    {
                        this.LoginError_label.ForeColor = Color.Red;
                        this.LoginError_label.Text = "Error!!Incorrect username or password";
                    }

                }
                
            }
        }

        private void Register_linkLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Register register = new Register();
            register.ShowDialog();
            this.Show();
        }
        
        private void Login_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.image1;
            Register_linkLabel.BackColor = System.Drawing.Color.Transparent;
            LoginPassword_textBox.PasswordChar = '*';
            this.BackColor = Color.SteelBlue;
        }

        private void ExitLogin_button_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
