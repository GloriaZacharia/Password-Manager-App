﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18131611
{
    class EncryptDecrypt
    {
        private string Key = "abcdefghijklmnopqrstuvwxyz";
        private char temp; 
        public string encryptdecrypt(string input)
        {
            StringBuilder inputStringBuild = new StringBuilder(input); //holds the input string
            StringBuilder outputStringBuild = new StringBuilder(input.Length);//hold sthe output string
            for(int i=0;i<input.Length;i++) // as long as we have not reached the end of the input string
            {
                temp = inputStringBuild[i]; //get the next character of the input string
                temp = (char)(temp ^ Key[i]); //perform XOR operation between the current characters of the input string and the key
                outputStringBuild.Append(temp); // append the generated character into the output string
            }
            return outputStringBuild.ToString(); //return the resulting string
        }
        
    }
}
