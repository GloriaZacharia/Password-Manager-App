﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _18131611
{
    public partial class PasswordInformation_label : Form
    {
        public int userId=0;
        public PasswordInformation_label(int userid)
        {
            InitializeComponent();
            userId = userid;
        } 

        private void PasswordInformation_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = Properties.Resources.image1;
            RandomPasswordGenerator randompasswordgenerator = new RandomPasswordGenerator();
            AddPassword_textBox.Text = randompasswordgenerator.generateRandomPassword(8); //Generate a random string
            AddDateCreated_textBox.Text = DateTime.Now.ToString(); //populate the random string to the appropriate area
            AddDateLastUpdated_textBox.Text = DateTime.Now.ToString(); //set the curent date as last updated

        }

        private void SavePasswordInformation_button_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(AddUsername_textBox.Text) || String.IsNullOrEmpty(AddPassword_textBox.Text)) //Chec if all the required fields are set
            {
                MessageBox.Show("Please input all the required details", "Warning", MessageBoxButtons.OK);
            }
            else //if all the required fields are ste
            {
                //create a table to hold all the new password information
                DataTable newPasswordInfo = new DataTable();
                newPasswordInfo.Columns.Add("Name", typeof(string));
                newPasswordInfo.Columns.Add("Username", typeof(string));
                newPasswordInfo.Columns.Add("Password", typeof(string));
                newPasswordInfo.Columns.Add("WebsiteUrl", typeof(string));
                newPasswordInfo.Columns.Add("GameDeveloper", typeof(string));
                newPasswordInfo.Columns.Add("DateCreated", typeof(string));
                newPasswordInfo.Columns.Add("DateLastUpdated", typeof(string));
                newPasswordInfo.Columns.Add("Type", typeof(string));
                newPasswordInfo.Columns.Add("UserId", typeof(int));

                EncryptDecrypt encrypt = new EncryptDecrypt();
                string text = encrypt.encryptdecrypt(AddPassword_textBox.Text); //encrypt the password value
                newPasswordInfo.Rows.Add(AddName_textBox.Text, AddUsername_textBox.Text, text, AddWebsiteUrl_textBox.Text, AddGameDeveloper_textBox.Text, AddDateCreated_textBox.Text,AddDateLastUpdated_textBox.Text,PasswordType_textBox.Text,userId);
                Database database = new Database();
                database.addPassworInformation(newPasswordInfo); //save the information to the database
                this.DialogResult = DialogResult.OK; 
            }
        }

        private void CancelAdd_button_Click(object sender, EventArgs e)
        {
            this.Close(); //Abort 
        }
    }
}
