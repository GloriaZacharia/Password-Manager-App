﻿
namespace _18131611
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RegisterFName_textBox = new System.Windows.Forms.TextBox();
            this.RegisterSName_textBox = new System.Windows.Forms.TextBox();
            this.RegisterAddress_textBox = new System.Windows.Forms.TextBox();
            this.RegisterUsername_textBox = new System.Windows.Forms.TextBox();
            this.RegisterPassword_textBox = new System.Windows.Forms.TextBox();
            this.RegisterFName_label = new System.Windows.Forms.Label();
            this.RegisterSName_label = new System.Windows.Forms.Label();
            this.RegisterAddress_label = new System.Windows.Forms.Label();
            this.RegisterUsername_label = new System.Windows.Forms.Label();
            this.RegisterPassword_label = new System.Windows.Forms.Label();
            this.Register_button = new System.Windows.Forms.Button();
            this.CancelRegister_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RegisterFName_textBox
            // 
            this.RegisterFName_textBox.BackColor = System.Drawing.Color.Cornsilk;
            this.RegisterFName_textBox.Location = new System.Drawing.Point(509, 178);
            this.RegisterFName_textBox.Name = "RegisterFName_textBox";
            this.RegisterFName_textBox.Size = new System.Drawing.Size(315, 38);
            this.RegisterFName_textBox.TabIndex = 0;
            // 
            // RegisterSName_textBox
            // 
            this.RegisterSName_textBox.BackColor = System.Drawing.Color.Cornsilk;
            this.RegisterSName_textBox.Location = new System.Drawing.Point(509, 296);
            this.RegisterSName_textBox.Name = "RegisterSName_textBox";
            this.RegisterSName_textBox.Size = new System.Drawing.Size(315, 38);
            this.RegisterSName_textBox.TabIndex = 1;
            // 
            // RegisterAddress_textBox
            // 
            this.RegisterAddress_textBox.BackColor = System.Drawing.Color.Cornsilk;
            this.RegisterAddress_textBox.Location = new System.Drawing.Point(509, 422);
            this.RegisterAddress_textBox.Name = "RegisterAddress_textBox";
            this.RegisterAddress_textBox.Size = new System.Drawing.Size(315, 38);
            this.RegisterAddress_textBox.TabIndex = 2;
            // 
            // RegisterUsername_textBox
            // 
            this.RegisterUsername_textBox.BackColor = System.Drawing.Color.Cornsilk;
            this.RegisterUsername_textBox.Location = new System.Drawing.Point(509, 555);
            this.RegisterUsername_textBox.Name = "RegisterUsername_textBox";
            this.RegisterUsername_textBox.Size = new System.Drawing.Size(315, 38);
            this.RegisterUsername_textBox.TabIndex = 3;
            // 
            // RegisterPassword_textBox
            // 
            this.RegisterPassword_textBox.BackColor = System.Drawing.Color.Cornsilk;
            this.RegisterPassword_textBox.Location = new System.Drawing.Point(509, 686);
            this.RegisterPassword_textBox.Name = "RegisterPassword_textBox";
            this.RegisterPassword_textBox.Size = new System.Drawing.Size(315, 38);
            this.RegisterPassword_textBox.TabIndex = 4;
            // 
            // RegisterFName_label
            // 
            this.RegisterFName_label.AutoSize = true;
            this.RegisterFName_label.BackColor = System.Drawing.Color.Transparent;
            this.RegisterFName_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterFName_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.RegisterFName_label.Location = new System.Drawing.Point(158, 169);
            this.RegisterFName_label.Name = "RegisterFName_label";
            this.RegisterFName_label.Size = new System.Drawing.Size(232, 46);
            this.RegisterFName_label.TabIndex = 5;
            this.RegisterFName_label.Text = "First Name";
            // 
            // RegisterSName_label
            // 
            this.RegisterSName_label.AutoSize = true;
            this.RegisterSName_label.BackColor = System.Drawing.Color.Transparent;
            this.RegisterSName_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterSName_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.RegisterSName_label.Location = new System.Drawing.Point(157, 287);
            this.RegisterSName_label.Name = "RegisterSName_label";
            this.RegisterSName_label.Size = new System.Drawing.Size(291, 46);
            this.RegisterSName_label.TabIndex = 6;
            this.RegisterSName_label.Text = "Second Name";
            // 
            // RegisterAddress_label
            // 
            this.RegisterAddress_label.AutoSize = true;
            this.RegisterAddress_label.BackColor = System.Drawing.Color.Transparent;
            this.RegisterAddress_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterAddress_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.RegisterAddress_label.Location = new System.Drawing.Point(158, 422);
            this.RegisterAddress_label.Name = "RegisterAddress_label";
            this.RegisterAddress_label.Size = new System.Drawing.Size(185, 46);
            this.RegisterAddress_label.TabIndex = 7;
            this.RegisterAddress_label.Text = "Address";
            // 
            // RegisterUsername_label
            // 
            this.RegisterUsername_label.AutoSize = true;
            this.RegisterUsername_label.BackColor = System.Drawing.Color.Transparent;
            this.RegisterUsername_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterUsername_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.RegisterUsername_label.Location = new System.Drawing.Point(158, 555);
            this.RegisterUsername_label.Name = "RegisterUsername_label";
            this.RegisterUsername_label.Size = new System.Drawing.Size(239, 46);
            this.RegisterUsername_label.TabIndex = 8;
            this.RegisterUsername_label.Text = "Username*";
            // 
            // RegisterPassword_label
            // 
            this.RegisterPassword_label.AutoSize = true;
            this.RegisterPassword_label.BackColor = System.Drawing.Color.Transparent;
            this.RegisterPassword_label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RegisterPassword_label.ForeColor = System.Drawing.Color.Cornsilk;
            this.RegisterPassword_label.Location = new System.Drawing.Point(176, 677);
            this.RegisterPassword_label.Name = "RegisterPassword_label";
            this.RegisterPassword_label.Size = new System.Drawing.Size(233, 46);
            this.RegisterPassword_label.TabIndex = 9;
            this.RegisterPassword_label.Text = "Password*";
            // 
            // Register_button
            // 
            this.Register_button.BackColor = System.Drawing.Color.Cornsilk;
            this.Register_button.Location = new System.Drawing.Point(569, 829);
            this.Register_button.Name = "Register_button";
            this.Register_button.Size = new System.Drawing.Size(150, 63);
            this.Register_button.TabIndex = 10;
            this.Register_button.Text = "Register";
            this.Register_button.UseVisualStyleBackColor = false;
            this.Register_button.Click += new System.EventHandler(this.Register_button_Click);
            // 
            // CancelRegister_button
            // 
            this.CancelRegister_button.BackColor = System.Drawing.Color.Cornsilk;
            this.CancelRegister_button.Location = new System.Drawing.Point(569, 940);
            this.CancelRegister_button.Name = "CancelRegister_button";
            this.CancelRegister_button.Size = new System.Drawing.Size(150, 59);
            this.CancelRegister_button.TabIndex = 11;
            this.CancelRegister_button.Text = "Cancel";
            this.CancelRegister_button.UseVisualStyleBackColor = false;
            this.CancelRegister_button.Click += new System.EventHandler(this.CancelRegister_button_Click);
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1740, 1145);
            this.Controls.Add(this.CancelRegister_button);
            this.Controls.Add(this.Register_button);
            this.Controls.Add(this.RegisterPassword_label);
            this.Controls.Add(this.RegisterUsername_label);
            this.Controls.Add(this.RegisterAddress_label);
            this.Controls.Add(this.RegisterSName_label);
            this.Controls.Add(this.RegisterFName_label);
            this.Controls.Add(this.RegisterPassword_textBox);
            this.Controls.Add(this.RegisterUsername_textBox);
            this.Controls.Add(this.RegisterAddress_textBox);
            this.Controls.Add(this.RegisterSName_textBox);
            this.Controls.Add(this.RegisterFName_textBox);
            this.Name = "Register";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Register_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox RegisterFName_textBox;
        private System.Windows.Forms.TextBox RegisterSName_textBox;
        private System.Windows.Forms.TextBox RegisterAddress_textBox;
        private System.Windows.Forms.TextBox RegisterUsername_textBox;
        private System.Windows.Forms.TextBox RegisterPassword_textBox;
        private System.Windows.Forms.Label RegisterFName_label;
        private System.Windows.Forms.Label RegisterSName_label;
        private System.Windows.Forms.Label RegisterAddress_label;
        private System.Windows.Forms.Label RegisterUsername_label;
        private System.Windows.Forms.Label RegisterPassword_label;
        private System.Windows.Forms.Button Register_button;
        private System.Windows.Forms.Button CancelRegister_button;
    }
}

